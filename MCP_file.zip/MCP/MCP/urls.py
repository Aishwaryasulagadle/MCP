"""
URL configuration for MCP project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""



from django.urls import include, path
from django.http import JsonResponse
from app1.views import generate_persona

def home(request):
    return JsonResponse({
        "message": "Welcome to MCP API",
        "available_endpoints": {
            "generate_persona": "/generate-persona/",
            "api_personas": "/api/personas/",
            "api_generate_persona": "/api/generate-persona/",
            "api_compare_personas": "/api/compare-personas/",
            "api_create_segments": "/api/create-segments/",
            "admin": "/admin/"
        }
    })

urlpatterns = [
    path('', home, name='home'),
    path('generate-persona/', generate_persona),
    path('api/', include('app1.urls'), name='api'),
]   