from django.db import models

# Create your models here.


class User(models.Model):
    name = models.CharField(max_length=100)
    job = models.CharField(max_length=100)
    spending = models.CharField(max_length=50)
    activity = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Persona(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    pain_points = models.TextField()
    goals = models.TextField()
    tone = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class Segment(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    personas = models.ManyToManyField(Persona, related_name='segments')

    def __str__(self):
        return self.name

