from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import User, Persona, Segment
from .serializers import PersonaSerializer, SegmentSerializer
from django.db.models import Q


# Logic for persona generation
def generate_persona_logic(job, spending, activity):
    if job == "Founder":
        persona_name = "Startup Founder"
        tone = "professional"
        description = "Entrepreneur focused on building and scaling businesses."
        pain_points = "time constraints, funding challenges"
        goals = "company growth, innovation"
    elif spending == "low":
        persona_name = "Budget User"
        tone = "casual"
        description = "Cost-conscious individual seeking value for money."
        pain_points = "financial limitations, affordability"
        goals = "saving money, practical solutions"
    elif activity == "high":
        persona_name = "Active User"
        tone = "energetic"
        description = "Highly engaged user who interacts frequently."
        pain_points = "time management, information overload"
        goals = "efficiency, productivity"
    else:
        persona_name = "General User"
        tone = "neutral"
        description = "Typical user with standard needs."
        pain_points = "general usability issues"
        goals = "convenience, reliability"

    return {
        'name': persona_name,
        'description': description,
        'pain_points': pain_points,
        'goals': goals,
        'tone': tone
    }


# Grouping rules for segments
def group_personas_into_segments():
    # Example grouping logic
    professional_personas = Persona.objects.filter(tone='professional')
    casual_personas = Persona.objects.filter(tone='casual')
    neutral_personas = Persona.objects.filter(tone='neutral')

    # Create or update segments
    prof_segment, created = Segment.objects.get_or_create(
        name='Professional Segment',
        defaults={'description': 'Personas with professional tone'}
    )
    prof_segment.personas.set(professional_personas)

    casual_segment, created = Segment.objects.get_or_create(
        name='Casual Segment',
        defaults={'description': 'Personas with casual tone'}
    )
    casual_segment.personas.set(casual_personas)

    neutral_segment, created = Segment.objects.get_or_create(
        name='Neutral Segment',
        defaults={'description': 'Personas with neutral tone'}
    )
    neutral_segment.personas.set(neutral_personas)

    return [prof_segment, casual_segment, neutral_segment]


@api_view(['GET'])
def get_personas(request):
    try:
        personas = Persona.objects.all()
        serializer = PersonaSerializer(personas, many=True)
        return Response(serializer.data)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
def generate_persona(request):
    try:
        job = request.data.get('job')
        spending = request.data.get('spending')
        activity = request.data.get('activity')

        if not job or not spending:
            return Response({'error': 'job and spending are required'}, status=status.HTTP_400_BAD_REQUEST)

        persona_data = generate_persona_logic(job, spending, activity)

        persona = Persona.objects.create(**persona_data)

        serializer = PersonaSerializer(persona)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
def compare_personas(request):
    try:
        persona1_id = request.data.get('persona1_id')
        persona2_id = request.data.get('persona2_id')

        if not persona1_id or not persona2_id:
            return Response({'error': 'persona1_id and persona2_id are required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            persona1 = Persona.objects.get(id=persona1_id)
            persona2 = Persona.objects.get(id=persona2_id)
        except Persona.DoesNotExist:
            return Response({'error': 'One or both personas not found'}, status=status.HTTP_404_NOT_FOUND)

        comparison = {
            'persona1': PersonaSerializer(persona1).data,
            'persona2': PersonaSerializer(persona2).data,
            'similarities': [],
            'differences': []
        }

        # Simple comparison logic
        if persona1.tone == persona2.tone:
            comparison['similarities'].append('Same tone')
        else:
            comparison['differences'].append(f'Tone: {persona1.tone} vs {persona2.tone}')

        if persona1.goals == persona2.goals:
            comparison['similarities'].append('Same goals')
        else:
            comparison['differences'].append(f'Goals: {persona1.goals} vs {persona2.goals}')

        return Response(comparison)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
def create_segments(request):
    try:
        segments = group_personas_into_segments()
        serializer = SegmentSerializer(segments, many=True)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
