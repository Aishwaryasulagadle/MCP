from rest_framework import serializers
from .models import User, Persona, Segment


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'


class PersonaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Persona
        fields = '__all__'


class SegmentSerializer(serializers.ModelSerializer):
    personas = PersonaSerializer(many=True, read_only=True)

    class Meta:
        model = Segment
        fields = '__all__'