from django.urls import path
from . import views

urlpatterns = [
    path('personas/', views.get_personas, name='get_personas'),
    path('generate-persona/', views.generate_persona, name='generate_persona'),
    path('compare-personas/', views.compare_personas, name='compare_personas'),
    path('create-segments/', views.create_segments, name='create_segments'),
]